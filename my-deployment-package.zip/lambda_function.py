import json
import boto3
import json
import requests


def lambda_handler(event, context):

    if "Records" in event.keys():
        for record in event['Records']:
            print("test")
            api_url = "https://eo2m23s1skd9jmr.m.pipedream.net/"
            todo = {"userId": record, "title": "Buy milk", "completed": False}
            headers =  {"Content-Type":"application/json"}
            response = requests.post(api_url, data=json.dumps(todo), headers=headers) 
        
   
    
    
    # TODO implement
    s3 = boto3.resource('s3',
                    aws_access_key_id="AKIA2P5U2TLSHSBYNEXU",
                    aws_secret_access_key="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"
                    )
    #input file for transforming 200 records
    #content_object = s3.Object('kula-ai-global-dev', 'brightdata/2023/1/Linkedin_profile_collector_20230116_060016.1673848814776.2.json')
    #input file for transforming 1000 records
    content_object = s3.Object('brightdatakula', 'Linkedin_profile_collector_20230116_060016.1673848814776.1_upload.json')
    #output file
    #content_object = s3.Object('kula-ai-global-dev', 'brightdata/2023/2/Linkedin_profile_collector_20230116_060016.1673848814776.1.json')
    #content_object = s3.Object('kula-ai-global-dev', 'brightdata/2023/Linkedin_profile_collector_20230116_044320.1673844199373.1.json')
    print("Test")
    print(content_object.get()['Body'])
    print("Test")
    file_content = content_object.get()['Body'].read().decode('utf-8')
    #print(file_content)
   # json_content = json.loads(file_content)
    print("-----------------------Test")
    #print(json_content)
    
    s3.Bucket('targetbrightdatakula').put_object(Bucket= "targetbrightdatakula",Key= "Test.json",Body= json.dumps(context, ensure_ascii=False).encode('utf8'))
    print("-----------------------Test")
    
    
   
    print ("over atudeo deplo")



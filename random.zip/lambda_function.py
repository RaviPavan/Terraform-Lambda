import json
import boto3
from datetime import datetime
import os

def lambda_handler(event, context):
    # TODO implement
    queue_url=os.environ['queue_url']
    now = datetime.now()
    current_time = now.strftime("%H:%M:%S %p")
    message_str = json.dumps(event)
    sqs = boto3.client('sqs')  #client is required to interact with 
    sqs.send_message( QueueUrl=queue_url,   MessageBody="TestLambaTrigger", MessageAttributes={        'EventDetails': {            'DataType': 'String',            'StringValue': message_str        }    }   )
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
